import subprocess

ingestion_script = "1_get_team_statistics.py"
transform_script = "2_transform_team_stats.py"
analysis_script = "3_data_analysis_prep.py"

subprocess.run(["python", ingestion_script])
print("Getting NHL Team Stats Data.")

subprocess.run(["python", transform_script])
print("Transforming NHL Team Stats Data for Win Percentage Reports.")

subprocess.run(["python", analysis_script])
print("Preparing NHL Win Percentage Files for Analysis.")
