import pandas as pd

team_stats_df = pd.read_csv("data/nhl_team_stats_and_standings.csv")

transformed_df = team_stats_df[['TEAM_NAME', 'TEAM_ABBR', 'GP', 'W', 'L', 'OT_L',
                                'PTS', 'PT_PCT', 'WIN_PCT', 'GF', 'GA',
                                'HOME_GA', 'HOME_GF', 'ROAD_GA', 'ROAD_GF']]

transformed_df['EXP_WIN_PCT'] = transformed_df['GF']**2 / (transformed_df['GF']**2 + transformed_df['GA']**2)
transformed_df['EXP_HOME_WIN_PCT'] = transformed_df['HOME_GF']**2 / (transformed_df['HOME_GF']**2 + transformed_df['HOME_GA']**2)
transformed_df['EXP_AWAY_WIN_PCT'] = transformed_df['ROAD_GF']**2 / (transformed_df['ROAD_GF']**2 + transformed_df['ROAD_GA']**2)

print(transformed_df.head())

csv_file_path = "data/win_percentage_team_data.csv"
transformed_df.to_csv(csv_file_path, index=False)