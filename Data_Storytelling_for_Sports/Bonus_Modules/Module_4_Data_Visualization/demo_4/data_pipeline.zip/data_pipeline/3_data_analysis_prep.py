import pandas as pd

wp_df = pd.read_csv("data/win_percentage_team_data.csv")

wp_df["VALUE_DIFF"] = wp_df["WIN_PCT"] - wp_df["EXP_WIN_PCT"]
wp_df["HOME_AWAY_DIFF"] = wp_df["EXP_HOME_WIN_PCT"] - wp_df["EXP_AWAY_WIN_PCT"]

value_picks = wp_df[["TEAM_NAME", "WIN_PCT", "EXP_WIN_PCT",
                     "VALUE_DIFF"]].sort_values(by="VALUE_DIFF", ascending=False)

value_picks.to_csv("data/nhl_value_picks.csv", index=False)

home_vs_away = wp_df[["TEAM_NAME", "EXP_HOME_WIN_PCT", "EXP_AWAY_WIN_PCT",
                      "HOME_AWAY_DIFF"]].sort_values(by="HOME_AWAY_DIFF", ascending=False)

home_vs_away.to_csv("data/home_vs_away.csv", index=False)